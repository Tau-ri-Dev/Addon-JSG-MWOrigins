# Just Stargate Mod | Milky Way Origins Library

This library provides extra textures and models of Milkyway's Point of Origins.

To run this library you need to have installed Just Stargate Mod (JSG).

## How to install this lib?
1. Download and extract .zip file from releases on GitHub or on CurseForge.
2. Open "src" folder
3. Merge "assets" folder with assets folder inside jsg config folder (Should be in .minecraft/config/jsg/)
4. Open "stargates-origins.cfg" file inside "config" folder
5. Copy content from this file and replace section "origins" in JSG stargates config file with this content
6. Launch Minecraft 1.12.2 with Forge and JSG mod